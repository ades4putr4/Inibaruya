import { Component, OnInit, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SplashComponent } from './components/splash.component';
import { DashboardComponent } from './components/dashboard.component';
import { TradeFormComponent } from './components/trade-form.component';
import { TradeListComponent } from './components/trade-list.component';
import { DataService, Trade } from './services/data.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, SplashComponent, DashboardComponent, TradeFormComponent, TradeListComponent],
  templateUrl: './app.component.html',
  styles: [`
    :host { display: block; height: 100vh; overflow: hidden; }
  `]
})
export class AppComponent implements OnInit {
  showSplash = signal(true);
  currentView = signal<'dashboard' | 'plan' | 'journal'>('dashboard');

  constructor(private dataService: DataService) {
    // Check local storage for "has visited" to optionally skip splash, but requirement says "Saat aplikasi pertama kali dibuka"
    // We will show it every reload for the "App" feel as per req.
  }

  ngOnInit() {
    setTimeout(() => {
      this.showSplash.set(false);
    }, 3000);
  }

  switchView(view: 'dashboard' | 'plan' | 'journal') {
    this.currentView.set(view);
  }
}