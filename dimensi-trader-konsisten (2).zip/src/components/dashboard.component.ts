import { Component, ElementRef, ViewChild, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../services/data.service';
import * as d3 from 'd3';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Cards Grid -->
      <div class="grid grid-cols-2 gap-4">
        <div class="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-lg">
          <p class="text-gray-400 text-xs font-medium uppercase tracking-wider">Win Rate</p>
          <div class="flex items-end space-x-2 mt-1">
            <h3 class="text-2xl font-bold text-white">{{ dataService.winRate() | number:'1.0-1' }}%</h3>
            <span class="text-xs text-gray-500 mb-1.5">{{ dataService.totalTrades() }} Trades</span>
          </div>
        </div>

        <div class="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-lg">
          <p class="text-gray-400 text-xs font-medium uppercase tracking-wider">Net Profit</p>
          <div class="mt-1">
            <h3 class="text-2xl font-bold" 
               [class.text-green-400]="dataService.totalProfit() >= 0"
               [class.text-red-400]="dataService.totalProfit() < 0">
              {{ dataService.totalProfit() >= 0 ? '+' : '' }}{{ dataService.totalProfit() | currency:'USD':'symbol':'1.0-0' }}
            </h3>
          </div>
        </div>
        
        <div class="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-lg">
          <p class="text-gray-400 text-xs font-medium uppercase tracking-wider">Wins</p>
          <h3 class="text-xl font-bold text-green-400 mt-1">{{ dataService.wins() }}</h3>
        </div>

        <div class="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-lg">
          <p class="text-gray-400 text-xs font-medium uppercase tracking-wider">Losses</p>
          <h3 class="text-xl font-bold text-red-400 mt-1">{{ dataService.losses() }}</h3>
        </div>
      </div>

      <!-- Charts Section -->
      <div class="bg-gray-800 p-4 rounded-xl border border-gray-700 shadow-lg">
        <h3 class="text-white font-semibold mb-4 text-sm uppercase tracking-wide border-b border-gray-700 pb-2">Equity Curve</h3>
        <div #chartContainer class="w-full h-64"></div>
      </div>
      
      <!-- Reset Button Area -->
      <div class="text-center pt-4">
        <button (click)="reset()" class="text-xs text-red-500 hover:text-red-400 underline p-2">
          Reset Semua Data
        </button>
      </div>
    </div>
  `
})
export class DashboardComponent {
  dataService = inject(DataService);
  
  @ViewChild('chartContainer') chartContainer!: ElementRef;

  constructor() {
    effect(() => {
      const data = this.dataService.equityCurve();
      if (this.chartContainer && data.length > 0) {
        this.renderChart(data);
      } else if (this.chartContainer) {
        // Clear chart if no data
        d3.select(this.chartContainer.nativeElement).selectAll('*').remove();
        d3.select(this.chartContainer.nativeElement)
          .append('div')
          .attr('class', 'h-full flex items-center justify-center text-gray-500 text-sm')
          .text('Belum ada data trading');
      }
    });
  }

  reset() {
    if(confirm('Yakin ingin menghapus semua data? Ini tidak bisa dikembalikan.')) {
      this.dataService.resetData();
    }
  }

  renderChart(data: any[]) {
    const element = this.chartContainer.nativeElement;
    d3.select(element).selectAll('*').remove();

    const margin = { top: 10, right: 10, bottom: 20, left: 40 };
    const width = element.offsetWidth - margin.left - margin.right;
    const height = element.offsetHeight - margin.top - margin.bottom;

    const svg = d3.select(element)
      .append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // X scale (Indices 0 to length)
    const x = d3.scaleLinear()
      .domain([0, data.length - 1])
      .range([0, width]);

    // Y scale
    const y = d3.scaleLinear()
      .domain([d3.min(data, (d: any) => d.value) || 0, d3.max(data, (d: any) => d.value) || 0])
      .range([height, 0])
      .nice();

    // Line
    const line = d3.line<any>()
      .x((d, i) => x(i))
      .y(d => y(d.value))
      .curve(d3.curveMonotoneX); // Smooth curve

    // Area (Gradient effect)
    const area = d3.area<any>()
      .x((d, i) => x(i))
      .y0(height)
      .y1(d => y(d.value))
      .curve(d3.curveMonotoneX);

    // Add Gradient
    const defs = svg.append("defs");
    const gradient = defs.append("linearGradient")
      .attr("id", "equity-gradient")
      .attr("x1", "0%")
      .attr("y1", "0%")
      .attr("x2", "0%")
      .attr("y2", "100%");
    
    gradient.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#D4AF37") // Gold
      .attr("stop-opacity", 0.3);
      
    gradient.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#D4AF37")
      .attr("stop-opacity", 0);

    // Draw Area
    svg.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area)
      .style("fill", "url(#equity-gradient)");

    // Draw Line
    svg.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "#D4AF37")
      .attr("stroke-width", 2)
      .attr("d", line);

    // Axes
    svg.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(data.length > 5 ? 5 : data.length).tickFormat(() => ''))
      .attr('color', '#4b5563');

    svg.append("g")
      .call(d3.axisLeft(y).ticks(5))
      .attr('color', '#4b5563')
      .selectAll("text")
      .style("fill", "#9ca3af")
      .style("font-size", "10px");

    // Add dots
    svg.selectAll(".dot")
      .data(data)
      .enter().append("circle")
      .attr("class", "dot")
      .attr("cx", (d, i) => x(i))
      .attr("cy", d => y(d.value))
      .attr("r", 3)
      .attr("fill", "#1F2937")
      .attr("stroke", "#D4AF37")
      .attr("stroke-width", 2);
  }
}