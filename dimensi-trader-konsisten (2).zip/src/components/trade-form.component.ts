import { Component, output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DataService, Trade } from '../services/data.service';

@Component({
  selector: 'app-trade-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="space-y-6">
      <!-- Title -->
      <div class="flex items-center justify-between">
        <h2 class="text-xl font-bold text-white">Buat Trading Plan</h2>
        <span class="text-xs text-amber-500 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20">AUTO CALCULATE</span>
      </div>

      <form [formGroup]="form" (ngSubmit)="saveTrade()" class="space-y-4">
        
        <!-- Pair & Type Row -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-medium text-gray-400 mb-1">Pair / Symbol</label>
            <input type="text" formControlName="pair" placeholder="XAUUSD" 
              class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all uppercase placeholder-gray-600">
          </div>
          <div>
            <label class="block text-xs font-medium text-gray-400 mb-1">Posisi</label>
            <div class="flex rounded-lg overflow-hidden border border-gray-700">
              <button type="button" (click)="setType('BUY')" 
                class="flex-1 p-3 text-sm font-bold transition-colors"
                [class.bg-green-600]="form.get('type')?.value === 'BUY'"
                [class.text-white]="form.get('type')?.value === 'BUY'"
                [class.bg-gray-800]="form.get('type')?.value !== 'BUY'"
                [class.text-gray-400]="form.get('type')?.value !== 'BUY'">
                BUY
              </button>
              <button type="button" (click)="setType('SELL')"
                class="flex-1 p-3 text-sm font-bold transition-colors"
                [class.bg-red-600]="form.get('type')?.value === 'SELL'"
                [class.text-white]="form.get('type')?.value === 'SELL'"
                [class.bg-gray-800]="form.get('type')?.value !== 'SELL'"
                [class.text-gray-400]="form.get('type')?.value !== 'SELL'">
                SELL
              </button>
            </div>
          </div>
        </div>

        <!-- Prices -->
        <div class="grid grid-cols-3 gap-3">
          <div>
            <label class="block text-xs font-medium text-gray-400 mb-1">Entry</label>
            <input type="number" formControlName="entry" placeholder="0.00" step="any"
              class="w-full bg-gray-800 border border-gray-700 rounded-lg p-2 text-white focus:ring-1 focus:ring-amber-500">
          </div>
          <div>
            <label class="block text-xs font-medium text-red-400 mb-1">Stop Loss</label>
            <input type="number" formControlName="sl" placeholder="0.00" step="any"
              class="w-full bg-gray-800 border border-red-900/50 rounded-lg p-2 text-white focus:ring-1 focus:ring-red-500">
          </div>
          <div>
            <label class="block text-xs font-medium text-green-400 mb-1">Take Profit</label>
            <input type="number" formControlName="tp" placeholder="0.00" step="any"
              class="w-full bg-gray-800 border border-green-900/50 rounded-lg p-2 text-white focus:ring-1 focus:ring-green-500">
          </div>
        </div>

        <!-- Money Management -->
        <div class="bg-gray-800/50 p-4 rounded-xl border border-gray-700 space-y-3">
          <h3 class="text-sm font-semibold text-gray-300 border-b border-gray-700 pb-2 mb-2">Money Management</h3>
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-medium text-gray-400 mb-1">Modal ($)</label>
              <input type="number" formControlName="capital" class="w-full bg-gray-800 border border-gray-600 rounded p-2 text-sm">
            </div>
            <div>
              <label class="block text-xs font-medium text-gray-400 mb-1">Risk (%)</label>
              <input type="number" formControlName="riskPercent" class="w-full bg-gray-800 border border-gray-600 rounded p-2 text-sm">
            </div>
          </div>
          
          <!-- Live Calculations -->
          <div class="grid grid-cols-3 gap-2 pt-2 text-center">
            <div class="bg-gray-800 rounded p-2 border border-gray-700">
              <div class="text-[10px] text-gray-500 uppercase">Risk $</div>
              <div class="text-sm font-bold text-red-400">{{ riskAmount | currency }}</div>
            </div>
            <div class="bg-gray-800 rounded p-2 border border-gray-700">
              <div class="text-[10px] text-gray-500 uppercase">RR Ratio</div>
              <div class="text-sm font-bold text-blue-400">1 : {{ rrRatio | number:'1.1-2' }}</div>
            </div>
            <div class="bg-gray-800 rounded p-2 border border-gray-700">
              <div class="text-[10px] text-gray-500 uppercase">Est. Lot</div>
              <div class="text-sm font-bold text-amber-500">{{ lotSize | number:'1.2-2' }}</div>
            </div>
          </div>
        </div>

        <!-- Result (Optional/Pre-fill) -->
        <div>
          <label class="block text-xs font-medium text-gray-400 mb-1">Catatan</label>
          <textarea formControlName="notes" rows="3" class="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-sm text-gray-300"></textarea>
        </div>

        <button type="submit" [disabled]="form.invalid"
          class="w-full bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-gray-900 font-bold py-4 rounded-xl shadow-lg transform transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed">
          SIMPAN PLAN
        </button>
      </form>
    </div>
  `
})
export class TradeFormComponent {
  private fb: FormBuilder = inject(FormBuilder);
  dataService = inject(DataService);
  viewChange = output<'dashboard' | 'plan' | 'journal'>();

  form: FormGroup = this.fb.group({
    pair: ['', Validators.required],
    type: ['BUY', Validators.required],
    entry: [null as number | null, Validators.required],
    sl: [null as number | null, Validators.required],
    tp: [null as number | null, Validators.required],
    capital: [1000, Validators.required],
    riskPercent: [1, Validators.required],
    notes: ['']
  });

  get riskAmount(): number {
    const capital = this.form.get('capital')?.value || 0;
    const risk = this.form.get('riskPercent')?.value || 0;
    return (capital * risk) / 100;
  }

  get rrRatio(): number {
    const entry = this.form.get('entry')?.value || 0;
    const sl = this.form.get('sl')?.value || 0;
    const tp = this.form.get('tp')?.value || 0;
    
    if (!entry || !sl || !tp) return 0;
    
    const risk = Math.abs(entry - sl);
    const reward = Math.abs(tp - entry);
    
    if (risk === 0) return 0;
    return reward / risk;
  }

  get lotSize(): number {
    const entry = this.form.get('entry')?.value || 0;
    const sl = this.form.get('sl')?.value || 0;
    
    if (!entry || !sl) return 0;
    const distance = Math.abs(entry - sl);
    if (distance === 0) return 0;
    
    return (this.riskAmount / distance);
  }

  setType(type: string) {
    this.form.get('type')?.setValue(type);
  }

  saveTrade() {
    if (this.form.invalid) return;

    const val = this.form.value;
    
    const newTrade: Trade = {
      id: self.crypto.randomUUID(),
      pair: (val.pair || '').toUpperCase(),
      type: val.type as 'BUY' | 'SELL',
      entry: val.entry || 0,
      sl: val.sl || 0,
      tp: val.tp || 0,
      result: 'OPEN',
      profit: 0,
      date: new Date().toISOString().split('T')[0],
      notes: val.notes || '',
      riskPercent: val.riskPercent || 0,
      lotSize: this.lotSize
    };

    this.dataService.addTrade(newTrade);
    this.form.reset({
      pair: '',
      type: 'BUY',
      capital: val.capital, // Keep capital
      riskPercent: val.riskPercent // Keep risk
    });
    
    this.viewChange.emit('journal');
  }
}
