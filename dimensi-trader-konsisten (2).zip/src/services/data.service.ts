import { Injectable, signal, computed, effect } from '@angular/core';

export interface Trade {
  id: string;
  pair: string;
  entry: number;
  sl: number;
  tp: number;
  type: 'BUY' | 'SELL';
  result: 'WIN' | 'LOSS' | 'BREAKEVEN' | 'OPEN';
  profit: number;
  date: string;
  notes: string;
  riskPercent: number;
  lotSize: number;
}

const STORAGE_KEY = 'dimensi_trader_data';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  trades = signal<Trade[]>([]);

  // Statistics
  totalTrades = computed(() => this.trades().length);
  
  wins = computed(() => this.trades().filter(t => t.result === 'WIN').length);
  losses = computed(() => this.trades().filter(t => t.result === 'LOSS').length);
  
  winRate = computed(() => {
    const total = this.trades().filter(t => t.result !== 'OPEN').length;
    if (total === 0) return 0;
    return (this.wins() / total) * 100;
  });

  totalProfit = computed(() => this.trades().reduce((acc, t) => acc + t.profit, 0));
  
  // Equity curve data (simplified)
  equityCurve = computed(() => {
    let runningBalance = 0; // Relative to start
    return this.trades()
      .slice()
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(t => {
        runningBalance += t.profit;
        return { date: t.date, value: runningBalance, id: t.id };
      });
  });

  constructor() {
    this.loadData();
    
    // Auto-save effect
    effect(() => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.trades()));
    });
  }

  loadData() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      this.trades.set(JSON.parse(stored));
    } else {
      // Default data as requested
      this.trades.set([
        {
          id: '1',
          pair: 'XAUUSD',
          type: 'BUY',
          entry: 2000, sl: 1990, tp: 2020,
          result: 'WIN',
          profit: 100,
          date: '2024-01-10',
          notes: 'Setup perfect support',
          riskPercent: 1,
          lotSize: 0.1
        },
        {
          id: '2',
          pair: 'BTCUSD',
          type: 'SELL',
          entry: 45000, sl: 45500, tp: 44000,
          result: 'LOSS',
          profit: -50,
          date: '2024-01-11',
          notes: 'News impact',
          riskPercent: 0.5,
          lotSize: 0.05
        },
        {
          id: '3',
          pair: 'XAUUSD',
          type: 'BUY',
          entry: 2010, sl: 2005, tp: 2025,
          result: 'WIN',
          profit: 120,
          date: '2024-01-12',
          notes: 'Re-entry',
          riskPercent: 1,
          lotSize: 0.12
        }
      ]);
    }
  }

  addTrade(trade: Trade) {
    this.trades.update(current => [trade, ...current]);
  }

  deleteTrade(id: string) {
    this.trades.update(current => current.filter(t => t.id !== id));
  }

  resetData() {
    this.trades.set([]);
    localStorage.removeItem(STORAGE_KEY);
  }
}